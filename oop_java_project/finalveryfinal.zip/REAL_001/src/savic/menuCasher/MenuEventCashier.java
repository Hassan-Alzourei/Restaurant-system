
package savic.menuCasher;


public interface MenuEventCashier 
{
    public void selected(int index, int subIndex);
    
}
